#include "proc_demo.h"

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = node_read,
    .write = node_write,
    .open = node_open,
    .release = node_close
};

char response[BUF_SIZE] = "Default proc_demo response\n";

int init_module(void) {
    struct proc_dir_entry *own_proc_node = 0;
    
    /* init ***********************************************/
    if(!(own_proc_node = proc_create(NODE_NAME,0,NULL,&fops))) {
        printk(KERN_ALERT "Cannot create /proc/%s\n",NODE_NAME);
        return -ENOMEM;
    }
    
    printk(KERN_ALERT "/proc/%s was created\n",NODE_NAME);

    return 0;
}

void cleanup_module(void) {
    remove_proc_entry(NODE_NAME,NULL);

    printk(KERN_ALERT "'%s' module has exited\n",NODE_NAME);
    return;
}

