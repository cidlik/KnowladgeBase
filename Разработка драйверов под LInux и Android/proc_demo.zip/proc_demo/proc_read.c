#include "proc_demo.h"

ssize_t node_read(struct file *file,char *buffer,size_t length,loff_t *offset) {

    int resp_length = strlen(response)+1;
    loff_t ofs = *offset;
    int i;

    if(ofs >= resp_length) return 0;

    if(ofs+length > resp_length) length = resp_length-ofs;

    for(i = ofs; i<resp_length; i++) buffer[i] = (response+ofs)[i];

    *offset += length;

    return length;

}
