#include "proc_demo.h"

int node_open(struct inode *inode,struct file *file) {

    return 0;
}

int node_close(struct inode *inode,struct file *file) {
    
    return 0;
}

