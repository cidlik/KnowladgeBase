#include "radio.h"
#include <linux/fs.h>

int init_module(void) {
    printk(KERN_ALERT "'%s' module loaded\n",DEV_NAME);
    
    return 0;
}

void cleanup_module(void) {
    printk(KERN_ALERT "'%s' module has exited\n",DEV_NAME);
	
    return;
}

int radio_open(struct inode *inode,struct file *file) {
    return 0;
}

int radio_release(struct inode *inode,struct file *file) {
    return 0;
}

