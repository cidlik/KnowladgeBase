#include "radio.h"

ssize_t radio_read(struct file *file,char *buffer,size_t length,loff_t *offset) {   
    char *msg = "This is simple device speaking\n";

    return length;
}
