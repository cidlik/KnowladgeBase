#include "radio.h"

ssize_t radio_write(struct file *file,const char *buffer,size_t length,loff_t *offset)
{
    return length;
}

